import replicate
import re




prompt = "what is software"
        # Use Replicate to generate text
client = replicate.Client(api_token="")
            
            # Use the client to run the model
output = client.run("meta/meta-llama-3.1-405b-instruct",input={"prompt": prompt, "max_tokens": 200})

# Join the list elements
raw_text = ''.join(output)

# Remove extra spaces and newlines
cleaned_text = re.sub(r'\s+', ' ', raw_text).strip()

print(cleaned_text)


