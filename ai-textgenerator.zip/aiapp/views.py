from django.shortcuts import render
import replicate
import re
# Create your views here.


def index(request):
    if request.method == "POST":
        input_text = request.POST["entered_text"]
        client = replicate.Client(api_token="r8_EEWVkq3e1DYhuubS3QwTZgPtFdlkkYW1nrcf6")
        output = client.run("meta/meta-llama-3.1-405b-instruct", input={"prompt":input_text,"max_token":200})
        final_response = "".join(output)
        cleaned_text = re.sub(r'\s+',' ', final_response).strip()
        print(cleaned_text)
        context = {"final_response": cleaned_text}
        return render(request,"index.html",context)

    else:

      return render(request,"index.html")